
package com.example.sharedpreferencesapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val logoutButton = findViewById<Button>(R.id.buttonLogout)

        logoutButton.setOnClickListener {
            Prefs.saveUserLogin(this, false)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
