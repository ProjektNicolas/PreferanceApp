
package com.example.sharedpreferencesapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class HomeActivity : AppCompatActivity() {

    private val fileName = "user_login_status.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val welcomeTextView = findViewById<TextView>(R.id.textViewWelcome)
        val logoutButton = findViewById<Button>(R.id.buttonLogout)

        welcomeTextView.text = "Welcome, ${getUsername()}!"

        logoutButton.setOnClickListener {
            logout()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun getUsername(): String {
        val file = File(filesDir, fileName)
        return if (file.exists()) file.readText() else "User"
    }

    private fun logout() {
        val file = File(filesDir, fileName)
        if (file.exists()) file.delete()
    }
}
